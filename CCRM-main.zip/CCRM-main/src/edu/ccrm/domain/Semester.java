package edu.ccrm.domain;
//this just explains the semesters
public enum Semester {
    SPRING, SUMMER, FALL
}
